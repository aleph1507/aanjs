# nodejs-photogrid
This repository has my personal code for the photogrid Nodejs app of the course All About Nodejs in Udemy.


The main focus of this app is to introduce NodeJs capabilities of handling files on the server and sending them into the S3 AWS bucket. 

# Techs
* Amazon AWS (S3 ,EC2, cloudFront)
* GraphicsMagick image processing
* MongoLab and MOngoose
